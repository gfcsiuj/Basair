
export const API_BASE = 'https://api.quran.com/api/v4';
export const AUDIO_BASE = 'https://verses.quran.com/';
export const TOTAL_PAGES = 604;
